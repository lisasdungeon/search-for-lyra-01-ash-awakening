# Changelog

## System edition split — 2026-08-24

- Recorded the four supplied package sources and their exact manifest constraints.
- Split D&D 5e, PF1, and WFRP4e into standalone edition repositories.
- Deferred PF2e because the supplied `pf2e` directory is a Starfinder content module rather than the PF2e game system.

All notable changes to this module are documented here.

## [0.1.0] - 2026-08-24

### Added

- Initial standalone and campaign-mode adventure design for The Ash Awakening.
- GM adventure, NPC template, item template, handout, roll-table, and Scene compendiums.
- System-neutral scaling framework for later game-system adapters.
- Original cover illustration and Volkov Manor map.
- Deterministic LevelDB pack compiler, validation suite, release packaging, and measured coverage gates.

### Status

- Development build awaiting Odinn's review and sign-off.
- No Foundry version or game system has been marked verified.
