# System Source Audit

Date: 2026-08-24

This audit records the local packages supplied for native Search for Lyra editions. It is a development record, not a compatibility claim.

| Supplied directory | Detected package | Version | Foundry range | Result |
|---|---|---:|---:|---|
| `dnd5e-release-5.3.3` | D&D Fifth Edition system (`dnd5e`) | 5.3.3 | 13.347–14 | Native edition authored, packaged, and schema-tested |
| `pf1` | Pathfinder First Edition system (`pf1`) | 11.11 | 12–13 | Native edition authored, packaged, and schema-tested; runtime test requires Foundry 13 |
| `pf2e` | Starfinder Anachronism content module (`sf2e-anachronism`) | 2.3.0 | 14.360–14.366 | Not a PF2e system source; native PF2e edition is blocked until the actual `pf2e` system directory is supplied |
| `wfrp4e` | Warhammer Fantasy Roleplay system (`wfrp4e`) | 9.6.4 | 13–14 | Native edition authored, packaged, and schema-tested; runtime test requires the missing `warhammer-lib` dependency |

## Edition repositories

- `ld-search-for-lyra-01-ash-awakening-dnd5e`
- `ld-search-for-lyra-01-ash-awakening-pf1`
- `ld-search-for-lyra-01-ash-awakening-wfrp4e`

Each edition is a standalone Foundry module with its own manifest, LevelDB compendiums, release archive, changelog, tests, and git history. None is marked complete pending Odinn's review and the outstanding manual runtime gates.
