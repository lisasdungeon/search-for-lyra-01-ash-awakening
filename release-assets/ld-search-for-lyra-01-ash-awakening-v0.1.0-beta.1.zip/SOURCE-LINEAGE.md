# Source Lineage

## Adventure source

The Ash Awakening is rebuilt from Session 001 of the Search for Lyra source archive. This edition is a separate commercial one-shot product and does not depend on the source campaign repository at runtime.

## Vampire NPC casting

| One-shot role | Lisa's Dungeon Vampire NPC source | Adaptation |
|---|---|---|
| Patron and house ruler | Daria Volkov | Command identity becomes a social patron; combat power is scaled to the chosen system and party tier |
| Steward and intelligence gatekeeper | Captain Elara Voss | Intelligence-controller identity becomes the manor's ambiguous keeper of clues |
| Memory-cutting intruder | Sgt. Riven Dreamthief | Dream and memory theft identity becomes the one-shot's manifested antagonist |
| Missing Lyra | Lyssa Markova template lineage | Stealth, deception, and memory themes inform Lyra without replacing Lyra's scenario identity |
| Estate retainers | Brak "Runt" Holt | Recruit identity becomes the baseline retainer/minion template |

Original roster records are retained under `design-source/vampire-cast/` for traceability and are excluded from the release archive.

## Visual assets

- `assets/art/ash-awakening-cover.webp`: original product cover illustration created for this module.
- `assets/maps/volkov-manor.webp`: original top-down manor map created for this module.

