# Search for Lyra 01: The Ash Awakening — WFRP4e Edition

The Ash Awakening is a gothic-horror one-shot for WFRP4e 9.6.4 on Foundry VTT 13–14 and the first episode of the Search for Lyra campaign. The characters awaken in a sealed vampire manor with precise holes cut from their memories. Before the ash storm breaks the house apart, they must identify the intruder, learn why Lyra was taken, and choose what truth they carry outside.

## Product status

Version `0.1.0` is a development build. It is not a finished or published release and remains pending Odinn's review and sign-off.

## Included content

- Complete three-to-five hour adventure in standalone and campaign modes
- GM quick start, scene sequence, clues, countdown, endings, and fail-forward guidance
- Five system-neutral NPC guides adapted from the Lisa's Dungeon Vampire NPC library
- Five native WFRP4e NPC Actors with embedded actions and tier-scaling notes
- Three system-neutral item guides and three native WFRP4e clue Items
- Three roll tables
- Three player-safe handouts
- One ready-to-import manor Scene with an original map
- Original cover art

## Compatibility

This edition targets exactly WFRP4e `9.6.4` and Foundry VTT `13`–`14`. WFRP4e requires `warhammer-lib` 2.10.0 or newer; that dependency was not included in the supplied folder. The module has no runtime scripts, and manual world testing with the dependency installed remains an acceptance requirement before publication.

## Development

```bash
npm install
npm test
npm run build:packs
npm run validate
npm run pack
```

The repository disables npm binary links and dependency lifecycle scripts so installs work on filesystems that do not support symbolic links. The build invokes Node modules directly and does not depend on `node_modules/.bin`.

The generated LevelDB compendiums are written to `packs/`. The clean release archive is written to `dist/module.zip`.

## Installation during development

1. Run `npm run pack`.
2. Extract `dist/module.zip` into the Foundry `Data/modules` directory.
3. Confirm the installed folder is named `ld-search-for-lyra-01-ash-awakening-wfrp4e`.
4. Enable the module in a test world.
5. Open the Search for Lyra compendium folder and begin with `00 - Start Here`.

## Support

- GitHub: https://github.com/lisasdungeon
- Discord: `MystryssLysa`
- Email: `Lisasdungeon@gmail.com`

## License

Copyright 2026 Lisa's Dungeon. All rights reserved. See [LICENSE](LICENSE).
