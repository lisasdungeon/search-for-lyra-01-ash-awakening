# Changelog

## 0.1.0 — WFRP4e development edition

- Added five native WFRP4e 9.6.4 NPC Actors with embedded original Traits and a weapon.
- Added three native WFRP4e clue Items.
- Added an exact WFRP4e system relationship and system-specific compendium declarations.
- Added schema validation and LevelDB encoding coverage for Actor embedded Items.
- Kept the edition pending Odinn's runtime review and sign-off.

All notable changes to this module are documented here.

## [0.1.0] - 2026-08-24

### Added

- Initial standalone and campaign-mode adventure design for The Ash Awakening.
- GM adventure, NPC template, item template, handout, roll-table, and Scene compendiums.
- System-neutral scaling framework for later game-system adapters.
- Original cover illustration and Volkov Manor map.
- Deterministic LevelDB pack compiler, validation suite, release packaging, and measured coverage gates.

### Status

- Development build awaiting Odinn's review and sign-off.
- No Foundry version or game system has been marked verified.
