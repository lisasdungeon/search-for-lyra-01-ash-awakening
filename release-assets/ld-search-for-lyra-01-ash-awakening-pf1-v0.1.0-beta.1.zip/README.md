# Search for Lyra 01: The Ash Awakening — PF1 Edition

The Ash Awakening is a gothic-horror one-shot for PF1 11.11 on Foundry VTT 12–13 and the first episode of the Search for Lyra campaign. The characters awaken in a sealed vampire manor with precise holes cut from their memories. Before the ash storm breaks the house apart, they must identify the intruder, learn why Lyra was taken, and choose what truth they carry outside.

## Product status

Version `0.1.0` is a development build. It is not a finished or published release and remains pending Odinn's review and sign-off.

## Included content

- Complete three-to-five hour adventure in standalone and campaign modes
- GM quick start, scene sequence, clues, countdown, endings, and fail-forward guidance
- Five system-neutral NPC guides adapted from the Lisa's Dungeon Vampire NPC library
- Five native PF1 NPC Actors with embedded actions and tier-scaling notes
- Three system-neutral item guides and three native PF1 clue Items
- Three roll tables
- Three player-safe handouts
- One ready-to-import manor Scene with an original map
- Original cover art

## Compatibility

This edition targets exactly PF1 `11.11`, whose supplied manifest supports Foundry VTT `12` through `13`. It has no runtime scripts; all content loads through compendium packs. Automated source, schema, archive, and LevelDB checks are included. Manual GM/player world testing under a supported Foundry version remains an acceptance requirement before publication.

## Development

```bash
npm install
npm test
npm run build:packs
npm run validate
npm run pack
```

The repository disables npm binary links and dependency lifecycle scripts so installs work on filesystems that do not support symbolic links. The build invokes Node modules directly and does not depend on `node_modules/.bin`.

The generated LevelDB compendiums are written to `packs/`. The clean release archive is written to `dist/module.zip`.

## Installation during development

1. Run `npm run pack`.
2. Extract `dist/module.zip` into the Foundry `Data/modules` directory.
3. Confirm the installed folder is named `ld-search-for-lyra-01-ash-awakening-pf1`.
4. Enable the module in a test world.
5. Open the Search for Lyra compendium folder and begin with `00 - Start Here`.

## Support

- GitHub: https://github.com/lisasdungeon
- Discord: `MystryssLysa`
- Email: `Lisasdungeon@gmail.com`

## License

Copyright 2026 Lisa's Dungeon. All rights reserved. See [LICENSE](LICENSE).
