# Changelog

## 0.1.0 — PF1 development edition

- Added five native PF1 11.11 NPC Actors with original class, attack, and feature records.
- Added three native PF1 clue Items.
- Added an exact PF1 system relationship and system-specific compendium declarations.
- Added schema validation and LevelDB encoding coverage for Actor embedded Items.
- Kept the edition pending Odinn's runtime review and sign-off.

All notable changes to this module are documented here.

## [0.1.0] - 2026-08-24

### Added

- Initial standalone and campaign-mode adventure design for The Ash Awakening.
- GM adventure, NPC template, item template, handout, roll-table, and Scene compendiums.
- System-neutral scaling framework for later game-system adapters.
- Original cover illustration and Volkov Manor map.
- Deterministic LevelDB pack compiler, validation suite, release packaging, and measured coverage gates.

### Status

- Development build awaiting Odinn's review and sign-off.
- No Foundry version or game system has been marked verified.
